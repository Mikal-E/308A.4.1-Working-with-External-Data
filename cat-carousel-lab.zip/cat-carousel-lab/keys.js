// Store your API key as a string here (this file will NOT be pushed to GitHub)
export const API_KEY = "";